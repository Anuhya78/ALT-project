"""
main.py — API + web server for the Explainable AI Framework for Loan
Default Prediction (Batch-2 course project).

Run:  uvicorn main:app --reload --port 8000
Then open http://127.0.0.1:8000 in a browser.

Requires artifacts/ to exist — run `python train.py` first.
"""

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from lime.lime_tabular import LimeTabularExplainer
from pydantic import BaseModel, Field

ROOT = Path(__file__).parent
ARTIFACTS = ROOT / "artifacts"
FRONTEND = ROOT.parent / "frontend"

app = FastAPI(title="Explainable Loan Default Prediction API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------- Load artifacts once at startup ----------
if not (ARTIFACTS / "best_model.pkl").exists():
    raise RuntimeError(
        "No trained model found. Run `python train.py` inside backend/ first."
    )

best_model = joblib.load(ARTIFACTS / "best_model.pkl")
scaler = joblib.load(ARTIFACTS / "scaler.pkl")
metrics = json.loads((ARTIFACTS / "metrics.json").read_text())
shap_importance = json.loads((ARTIFACTS / "shap_importance.json").read_text())

FEATURES = metrics["features"]
FEATURE_LABELS = metrics["feature_labels"]
BEST_MODEL_NAME = metrics["best_model"]
NEEDS_SCALING = metrics["needs_scaling"]

background = pd.read_csv(ARTIFACTS / "background_sample.csv")[FEATURES]
background_labels = pd.read_csv(ARTIFACTS / "background_labels.csv")["default"].values

lime_explainer = LimeTabularExplainer(
    training_data=background.values,
    feature_names=[FEATURE_LABELS[f] for f in FEATURES],
    class_names=["No Default", "Default"],
    training_labels=background_labels,
    mode="classification",
    discretize_continuous=True,
    random_state=42,
)


def _predict_proba_raw(X_raw: np.ndarray) -> np.ndarray:
    """predict_proba wrapper LIME can call directly on raw feature values."""
    if NEEDS_SCALING:
        X_in = scaler.transform(X_raw)
    else:
        X_in = X_raw
    return best_model.predict_proba(X_in)


# ---------- Request/response schemas ----------
class LoanApplication(BaseModel):
    credit_utilization: float = Field(..., ge=0, description="Total balance / total credit limit")
    age: int = Field(..., ge=18, le=110)
    late_30_59_days: int = Field(..., ge=0, description="Times 30-59 days past due")
    debt_ratio: float = Field(..., ge=0)
    monthly_income: float = Field(..., ge=0)
    open_credit_lines: int = Field(..., ge=0)
    late_90_plus_days: int = Field(..., ge=0)
    real_estate_loans: int = Field(..., ge=0)
    late_60_89_days: int = Field(..., ge=0)
    dependents: int = Field(..., ge=0)


# ---------- API routes ----------
@app.get("/api/metrics")
def get_metrics():
    return metrics


@app.get("/api/shap-importance")
def get_shap_importance():
    return {"best_model": BEST_MODEL_NAME, "importance": shap_importance}


@app.post("/api/predict")
def predict(app_data: LoanApplication):
    try:
        row = np.array([[getattr(app_data, f) for f in FEATURES]], dtype=float)
        proba = float(_predict_proba_raw(row)[0, 1])
        risk_band = (
            "High Risk" if proba >= 0.5 else "Moderate Risk" if proba >= 0.2 else "Low Risk"
        )

        exp = lime_explainer.explain_instance(
            row[0],
            _predict_proba_raw,
            num_features=len(FEATURES),
            num_samples=1500,
        )
        local_explanation = [
            {"rule": rule, "weight": round(float(weight), 5)} for rule, weight in exp.as_list()
        ]

        return {
            "default_probability": round(proba, 4),
            "risk_band": risk_band,
            "model_used": BEST_MODEL_NAME,
            "local_explanation": local_explanation,
        }
    except Exception as e:  # pragma: no cover
        raise HTTPException(status_code=400, detail=str(e))


# ---------- Serve the frontend ----------
app.mount("/assets", StaticFiles(directory=FRONTEND), name="assets")


@app.get("/")
def index():
    return FileResponse(FRONTEND / "index.html")
