"""
train.py — End-to-end training pipeline for the Explainable AI Framework
for Loan Default Prediction (Batch-2 course project).

Pipeline (matches the project's Approach diagram):
  Data Collection -> Preprocessing -> Feature Engineering -> EDA stats
  -> Train/Test Split -> Train 5 models -> Evaluate -> Select best model
  -> SHAP (global) + LIME (local, computed at inference time in main.py)

Dataset: "Give Me Some Credit" (Kaggle). 150,000 historical loan
applicants with a binary SeriousDlqin2yrs target (1 = defaulted /
seriously delinquent within 2 years).

Run:  python train.py
Produces everything under ./artifacts/ that main.py (the API) needs.
"""

import json
import time
import warnings
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import shap
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
    confusion_matrix,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier

warnings.filterwarnings("ignore")

ROOT = Path(__file__).parent
DATA_PATH = ROOT.parent / "data" / "cstraining.csv"
ARTIFACTS = ROOT / "artifacts"
ARTIFACTS.mkdir(exist_ok=True)

RENAME = {
    "SeriousDlqin2yrs": "default",
    "RevolvingUtilizationOfUnsecuredLines": "credit_utilization",
    "age": "age",
    "NumberOfTime30-59DaysPastDueNotWorse": "late_30_59_days",
    "DebtRatio": "debt_ratio",
    "MonthlyIncome": "monthly_income",
    "NumberOfOpenCreditLinesAndLoans": "open_credit_lines",
    "NumberOfTimes90DaysLate": "late_90_plus_days",
    "NumberRealEstateLoansOrLines": "real_estate_loans",
    "NumberOfTime60-89DaysPastDueNotWorse": "late_60_89_days",
    "NumberOfDependents": "dependents",
}

FEATURES = [
    "credit_utilization",
    "age",
    "late_30_59_days",
    "debt_ratio",
    "monthly_income",
    "open_credit_lines",
    "late_90_plus_days",
    "real_estate_loans",
    "late_60_89_days",
    "dependents",
]

FEATURE_LABELS = {
    "credit_utilization": "Credit Utilization Ratio",
    "age": "Age",
    "late_30_59_days": "Times 30-59 Days Late",
    "debt_ratio": "Debt-to-Income Ratio",
    "monthly_income": "Monthly Income",
    "open_credit_lines": "Open Credit Lines & Loans",
    "late_90_plus_days": "Times 90+ Days Late",
    "real_estate_loans": "Real Estate Loans/Lines",
    "late_60_89_days": "Times 60-89 Days Late",
    "dependents": "Number of Dependents",
}


def log(msg):
    print(f"[train] {msg}", flush=True)


def load_and_preprocess():
    log(f"Loading dataset from {DATA_PATH}")
    df = pd.read_csv(DATA_PATH, index_col=0)
    df = df.rename(columns=RENAME)

    n_raw = len(df)

    # --- Missing value handling ---
    df["monthly_income"] = df["monthly_income"].fillna(df["monthly_income"].median())
    df["dependents"] = df["dependents"].fillna(df["dependents"].median())

    # --- Outlier treatment ---
    # age=0 is a data-entry error in this dataset; utilization/debt-ratio are
    # capped at their 99.5th percentile to tame extreme outliers rather than
    # dropping records.
    df = df[df["age"] > 0]
    for col in ["credit_utilization", "debt_ratio", "monthly_income"]:
        cap = df[col].quantile(0.995)
        df[col] = df[col].clip(upper=cap)

    log(f"Rows: {n_raw} raw -> {len(df)} after cleaning")

    X = df[FEATURES].copy()
    y = df["default"].copy()

    eda_stats = {
        "n_records": int(len(df)),
        "default_rate": round(float(y.mean()), 4),
        "feature_ranges": {
            f: {
                "min": round(float(X[f].min()), 2),
                "max": round(float(X[f].max()), 2),
                "mean": round(float(X[f].mean()), 2),
                "median": round(float(X[f].median()), 2),
            }
            for f in FEATURES
        },
    }
    return X, y, eda_stats


def train_and_evaluate():
    X, y, eda_stats = load_and_preprocess()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # --- Feature scaling (fit on train only) ---
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # SVM is O(n^2)-ish; train it on a stratified subsample so the whole
    # pipeline finishes in a reasonable demo time without faking results.
    svm_sample_idx = (
        pd.Series(y_train.values)
        .groupby(y_train.values)
        .apply(lambda s: s.sample(min(len(s), 6000), random_state=42))
        .index.get_level_values(1)
    )
    X_train_svm = X_train_scaled[svm_sample_idx]
    y_train_svm = y_train.values[svm_sample_idx]

    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
        "Decision Tree": DecisionTreeClassifier(max_depth=6, class_weight="balanced", random_state=42),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, max_depth=10, class_weight="balanced", random_state=42, n_jobs=-1
        ),
        "XGBoost": XGBClassifier(
            n_estimators=300,
            max_depth=5,
            learning_rate=0.08,
            subsample=0.9,
            colsample_bytree=0.9,
            scale_pos_weight=(y_train == 0).sum() / (y_train == 1).sum(),
            eval_metric="logloss",
            random_state=42,
            n_jobs=-1,
        ),
        "SVM (RBF)": SVC(kernel="rbf", C=1.0, probability=True, class_weight="balanced", random_state=42),
    }

    results = {}
    fitted = {}
    roc_curves = {}

    for name, model in models.items():
        t0 = time.time()
        if name == "SVM (RBF)":
            model.fit(X_train_svm, y_train_svm)
        elif name in ("Logistic Regression",):
            model.fit(X_train_scaled, y_train)
        else:
            # tree-based models don't need scaling; train on raw features
            model.fit(X_train, y_train)
        fitted[name] = model

        if name in ("Logistic Regression", "SVM (RBF)"):
            proba = model.predict_proba(X_test_scaled)[:, 1]
        else:
            proba = model.predict_proba(X_test)[:, 1]
        preds = (proba >= 0.5).astype(int)

        acc = accuracy_score(y_test, preds)
        prec = precision_score(y_test, preds, zero_division=0)
        rec = recall_score(y_test, preds, zero_division=0)
        f1 = f1_score(y_test, preds, zero_division=0)
        auc = roc_auc_score(y_test, proba)
        cm = confusion_matrix(y_test, preds).tolist()
        fpr, tpr, _ = roc_curve(y_test, proba)
        # Downsample ROC curve points for a lighter JSON payload
        idx = np.linspace(0, len(fpr) - 1, min(60, len(fpr))).astype(int)

        results[name] = {
            "accuracy": round(float(acc), 4),
            "precision": round(float(prec), 4),
            "recall": round(float(rec), 4),
            "f1_score": round(float(f1), 4),
            "roc_auc": round(float(auc), 4),
            "confusion_matrix": cm,
            "train_seconds": round(time.time() - t0, 2),
        }
        roc_curves[name] = {
            "fpr": [round(float(v), 4) for v in fpr[idx]],
            "tpr": [round(float(v), 4) for v in tpr[idx]],
        }
        log(f"{name}: ROC-AUC={auc:.4f}  F1={f1:.4f}  ({results[name]['train_seconds']}s)")

    best_name = max(results, key=lambda k: results[k]["roc_auc"])
    log(f"Best performing model: {best_name} (ROC-AUC={results[best_name]['roc_auc']})")

    # --- SHAP: global feature importance for the best model ---
    best_model = fitted[best_name]
    if best_name in ("Logistic Regression", "SVM (RBF)"):
        background = shap.sample(X_train_scaled, 200, random_state=42)
        explainer = shap.KernelExplainer(best_model.predict_proba, background)
        shap_values = explainer.shap_values(shap.sample(X_test_scaled, 300, random_state=42))
        shap_values = shap_values[1] if isinstance(shap_values, list) else shap_values
    else:
        explainer = shap.TreeExplainer(best_model)
        sv = explainer.shap_values(X_test.sample(min(2000, len(X_test)), random_state=42))
        shap_values = sv[1] if isinstance(sv, list) else sv

    mean_abs_shap = np.abs(shap_values).mean(axis=0)
    shap_importance = sorted(
        [
            {"feature": FEATURE_LABELS[f], "key": f, "importance": round(float(v), 5)}
            for f, v in zip(FEATURES, mean_abs_shap)
        ],
        key=lambda d: d["importance"],
        reverse=True,
    )

    # --- Save artifacts ---
    joblib.dump(fitted[best_name], ARTIFACTS / "best_model.pkl")
    joblib.dump(scaler, ARTIFACTS / "scaler.pkl")
    joblib.dump(fitted, ARTIFACTS / "all_models.pkl")

    with open(ARTIFACTS / "metrics.json", "w") as f:
        json.dump(
            {
                "results": results,
                "roc_curves": roc_curves,
                "best_model": best_name,
                "needs_scaling": best_name in ("Logistic Regression", "SVM (RBF)"),
                "eda": eda_stats,
                "features": FEATURES,
                "feature_labels": FEATURE_LABELS,
            },
            f,
            indent=2,
        )

    with open(ARTIFACTS / "shap_importance.json", "w") as f:
        json.dump(shap_importance, f, indent=2)

    # Background sample used by LIME at inference time (kept small + as raw,
    # unscaled feature values matching the API's input contract)
    X_train.sample(min(2000, len(X_train)), random_state=42).to_csv(
        ARTIFACTS / "background_sample.csv", index=False
    )
    y_train.loc[X_train.sample(min(2000, len(X_train)), random_state=42).index].to_frame(
        "default"
    ).to_csv(ARTIFACTS / "background_labels.csv", index=False)

    log("All artifacts saved to backend/artifacts/")
    return results, best_name


if __name__ == "__main__":
    train_and_evaluate()
