# Ledger — Explainable AI Framework for Loan Default Prediction

Batch-2 course project (Applied ML for Text Analytics, 24ALT3101)
Team: Ch. Varshini &middot; Y. Anuhya &middot; D. Aarya Deeksha

A working end-to-end system: a real training pipeline on 150,000 historical
loan applicants ("Give Me Some Credit" dataset), 5 models compared head to
head, the best one promoted automatically, SHAP for global explainability,
and LIME for per-applicant local explainability — all served through a
single website.

## What's inside

```
project/
├── data/
│   └── cstraining.csv          # 150k historical loan applicants (already included)
├── backend/
│   ├── train.py                # preprocessing + trains 5 models + SHAP + saves artifacts
│   ├── main.py                 # FastAPI app: serves the API + the website
│   ├── requirements.txt
│   └── artifacts/              # already-trained model, included so it runs immediately
└── frontend/
    └── index.html              # the website (Overview / Explainability / Try a Prediction)
```

Two separate things happen here, and it helps to keep them straight when
you explain the project tomorrow:
- **`train.py`** is offline model-building: reads the dataset, cleans it,
  trains all 5 models, picks the best one by ROC-AUC, computes SHAP values,
  and saves everything to `backend/artifacts/`. You do **not** need to run
  this tonight — it's already been run once and the results are in the zip.
- **`main.py`** is the lightweight server: it just loads the already-trained
  model from `artifacts/` and answers requests from the website. This is
  the only thing you need to start for the demo.

## Step-by-step execution

Run every command from inside `project\backend`.

**1. Open the right folder**
```
cd path\to\project\backend
```
Everything below assumes you're standing in this folder — `main.py`,
`train.py`, and `artifacts\` all live here, and Python needs to find them
by relative path.

**2. Confirm Python and pip are linked**
```
python --version
python -m pip --version
```
Both should report the same Python install. Doing this first avoids the
"Fatal error in launcher" issue, which happens when a separate `uvicorn.exe`
shortcut points at a Python install that no longer exists — running
everything through `python -m` (steps 3 and 5) sidesteps that shortcut
entirely.
*Check:* both commands print a version number with no errors.

**3. Install the dependencies**
```
python -m pip install -r requirements.txt
```
This installs FastAPI (web framework), uvicorn (the server), scikit-learn
and XGBoost (the 5 ML models), SHAP and LIME (the explainability
libraries), and pandas/numpy/joblib (data handling).
*Check:* the command ends without a red "ERROR" line. Warnings in yellow
are fine.

**4. Check the trained model is present**
```
dir artifacts
```
You should see `best_model.pkl`, `scaler.pkl`, `metrics.json`, and
`shap_importance.json`.
*Check:* if this folder is empty or missing, run `python train.py` once
(~1–2 minutes) to regenerate it — that's the script described above.

**5. Start the web server**
```
python -m uvicorn main:app --reload --port 8000
```
*Check:* wait for the line `Uvicorn running on http://127.0.0.1:8000` in
the terminal — that means it's live. Leave this window open; closing it
stops the site.

**6. Open the website**
Go to `http://127.0.0.1:8000` in a browser.
*Check:* the page loads with the "Ledger" title bar and three tabs
(Overview / Explainability / Try a Prediction). If it doesn't load, the
terminal from step 5 almost always shows why.

**7. Verify the Overview and Explainability tabs**
*Check:* Overview shows a ROC-AUC leaderboard for all 5 models with
XGBoost on top (≈0.86) and ROC curves. Explainability shows a ranked bar
chart of features by SHAP importance, with Credit Utilization Ratio at the
top.

**8. Verify Try a Prediction end-to-end**
Click **Load: High-risk profile**, then **Score this applicant**.
*Check:* probability above 90%, red "High Risk" label, and LIME factors
(e.g. "Times 90+ Days Late > 0.00") pushing the score up. Then try
**Load: Low-risk profile** and confirm it flips to a low probability with
green factors pushing it down. This confirms live prediction is really
running the model, not showing static numbers.

## What to show tomorrow

1. **Overview** — the ROC-AUC leaderboard, ROC curves, and which model got
   automatically promoted, plus the preprocessing pipeline.
2. **Explainability** — SHAP global feature importance.
3. **Try a Prediction** — the "wow" moment: run the Low-risk and High-risk
   presets back to back and read out the LIME reasoning for each.

## Notes for the write-up

- Dataset: [Give Me Some Credit](https://www.kaggle.com/c/GiveMeSomeCredit)
  — 150,000 rows, `SeriousDlqin2yrs` target (defaulted / seriously
  delinquent within 2 years), 10 applicant features.
- Preprocessing: median imputation for missing income/dependents,
  99.5th-percentile capping on utilization/debt-ratio/income outliers,
  invalid ages dropped, stratified 80/20 train-test split.
- Models: Logistic Regression, Decision Tree, Random Forest, XGBoost,
  RBF SVM (SVM trained on a stratified subsample for tractable training
  time — noted in `train.py`).
- Metrics: accuracy, precision, recall, F1, ROC-AUC, confusion matrix —
  all computed on the same held-out test split for a fair comparison.
- Explainability: SHAP `TreeExplainer` for global importance on the
  promoted model; LIME `LimeTabularExplainer` computed live per prediction
  for local, per-applicant reasoning — matching the dual-explainability
  approach from your abstract and Review-1 slides.

## Troubleshooting

- **"Fatal error in launcher"** → don't run `uvicorn ...` directly; use
  `python -m uvicorn main:app --reload --port 8000` (step 5).
- **`ModuleNotFoundError`** → step 3 didn't install into the Python you're
  running. Re-run `python -m pip install -r requirements.txt` (the
  `python -m pip` form, not bare `pip`).
- **Port 8000 busy** → `python -m uvicorn main:app --reload --port 8001`
  and open that port instead.
- **Blank page at `/`** → check the terminal from step 5 says "Application
  startup complete"; if artifacts are missing it will refuse to start.
